package com.cjw.demo4_radarscan;


import android.os.Message;

public interface IHandleMessage {

    void handleMessage(Message msg);
}
