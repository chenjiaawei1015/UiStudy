package com.cjw.demo3_rolltext;


import android.os.Message;

public interface IHandleMessage {

    void handleMessage(Message msg);
}
